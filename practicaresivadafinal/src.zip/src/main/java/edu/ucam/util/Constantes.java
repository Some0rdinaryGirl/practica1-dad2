package edu.ucam.util;

public class Constantes {
	public static final String PARAM_ESPACIO = "PARAM_ESPACIO";
    public static final String PARAM_FECHA = "PARAM_FECHA";
    public static final String PARAM_NOMBRE = "PARAM_NOMBRE";
    public static final String PARAM_CONTRASENA = "PARAM_CONTRASENA";
}
