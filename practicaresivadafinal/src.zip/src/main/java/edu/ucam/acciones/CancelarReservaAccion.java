package edu.ucam.acciones;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;

import edu.ucam.dao.EspacioDAO;
import edu.ucam.dao.UsuarioDAO;
import edu.ucam.domain.Espacio;
import edu.ucam.domain.Hueco;
import edu.ucam.domain.Usuario;
import edu.ucam.interfaces.Accion;
import jakarta.servlet.ServletContext;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class CancelarReservaAccion implements Accion {

	@Override
	public String ejecutar(HttpServletRequest request, HttpServletResponse response) {
		ServletContext context = request.getServletContext();
	    HttpSession session = request.getSession();

	    String fechaTexto = request.getParameter("fecha");
	    LocalDateTime fecha = LocalDateTime.parse(fechaTexto);

	    Usuario usuario = (Usuario) session.getAttribute("USUARIO_SESION");
	    List<Hueco> reservados = usuario.getListaHuecosReservados();

	    reservados.removeIf(h -> h.getFecha().equals(fecha));

	    HashSet<Espacio> espacios = (HashSet<Espacio>) context.getAttribute("LISTA_ESPACIOS");
	    for (Espacio e : espacios) {
	        for (Hueco h : e.getHuecos()) {
	            if (h.getFecha().equals(fecha)) {
	                h.setOcupado(false);
	                break;
	            }
	        }
	    }

	    UsuarioDAO usuarioDAO = (UsuarioDAO) context.getAttribute("USUARIODAO");
	    usuarioDAO.insertar(usuario);
	    context.setAttribute("LISTA_USUARIOS", usuarioDAO.obtenerTodos());

	    EspacioDAO espacioDAO = (EspacioDAO) context.getAttribute("ESPACIODAO");
	    espacioDAO.guardar(espacios);
	    context.setAttribute("LISTA_ESPACIOS", espacios);
	    
	    return "/secured/main.jsp";
	}

}
